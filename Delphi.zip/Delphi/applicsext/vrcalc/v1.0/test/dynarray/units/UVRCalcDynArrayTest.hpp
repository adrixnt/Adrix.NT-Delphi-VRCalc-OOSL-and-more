// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UVRCalcDynArrayTest.pas' rev: 6.00

#ifndef UVRCalcDynArrayTestHPP
#define UVRCalcDynArrayTestHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Uvrcalcdynarraytest
{
//-- type declarations -------------------------------------------------------
typedef Extended TVRCalcValueType;

typedef DynamicArray<Extended >  TVRCalcValueTypeDynArray;

typedef Extended __fastcall (*TVRCalcBuiltInFuncType)(AnsiString aFuncName, TVRCalcValueTypeDynArray aArgsList);

typedef Extended __fastcall (*TVRCalcBuiltInXFuncType)(AnsiString aFuncName, const Extended * aArgsList, const int aArgsList_Size);

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TVRCalcValueTypeDynArray __fastcall ParseArgsList();
extern PACKAGE TVRCalcValueTypeDynArray __fastcall ParseArgsListX();

}	/* namespace Uvrcalcdynarraytest */
using namespace Uvrcalcdynarraytest;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UVRCalcDynArrayTest
