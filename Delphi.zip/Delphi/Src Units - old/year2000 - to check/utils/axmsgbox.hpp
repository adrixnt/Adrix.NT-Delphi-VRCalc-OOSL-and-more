//----------------------------------------------------------------------------
// AxMsgBox.hpp - bcbdcc32 generated hdr (DO NOT EDIT) rev: 0
// From: AxMsgBox.pas
//----------------------------------------------------------------------------
#ifndef AxMsgBoxHPP
#define AxMsgBoxHPP
//----------------------------------------------------------------------------
#include <Dialogs.hpp>
#include <System.hpp>
namespace Axmsgbox
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern long __fastcall NeutralLangId(void);
extern long __fastcall UserDefLangId(void);
extern long __fastcall SystemDefLangId(void);
extern System::AnsiString __fastcall GetSysErrMsgStr(long errId);
extern Word __fastcall UserConfirmBox(const System::AnsiString aMsgStr, int btnCount, Dialogs::TMsgDlgBtn 
	btn0, Dialogs::TMsgDlgBtn btn1, Dialogs::TMsgDlgBtn btn2, Dialogs::TMsgDlgBtn btn3);
extern Word __fastcall UserWarningBox(const System::AnsiString aMsgStr, int btnCount, Dialogs::TMsgDlgBtn 
	btn0, Dialogs::TMsgDlgBtn btn1, Dialogs::TMsgDlgBtn btn2, Dialogs::TMsgDlgBtn btn3);
extern Word __fastcall UserErrorBox(const System::AnsiString aMsgStr, int btnCount, Dialogs::TMsgDlgBtn 
	btn0, Dialogs::TMsgDlgBtn btn1, Dialogs::TMsgDlgBtn btn2, Dialogs::TMsgDlgBtn btn3);
extern Word __fastcall UserInfoBox(const System::AnsiString aMsgStr, int btnCount, Dialogs::TMsgDlgBtn 
	btn0, Dialogs::TMsgDlgBtn btn1, Dialogs::TMsgDlgBtn btn2, Dialogs::TMsgDlgBtn btn3);

}	/* namespace Axmsgbox */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Axmsgbox;
#endif
//-- end unit ----------------------------------------------------------------
#endif	// AxMsgBox
