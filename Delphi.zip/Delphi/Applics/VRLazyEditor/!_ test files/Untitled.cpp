// C/C++

#include <stdio.h>

	// this is the factorial function

	long int Fact (int n)
	{
		if (n <= 0)
			return 1L;
		else
			return n * Fact (n - 1);
	}

	int main()
	{
		for (int i = 0; i <= 10; ++i)
			printf ("%d : %ld\n", i, Fact(i));
		return 0;
	}

// that's all folks ...