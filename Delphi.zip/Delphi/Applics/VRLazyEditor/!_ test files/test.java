// java
class AClass
ident 10
++
"cazzo"
if (pacchio > 0) {
	// minchia code here
}