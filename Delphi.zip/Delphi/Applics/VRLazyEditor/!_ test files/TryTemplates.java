
public class ClassName
{
	// default constructor
	public ClassName() {}
}