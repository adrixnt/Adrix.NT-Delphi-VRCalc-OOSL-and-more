
public strictfp class Main
{
	public static void main (String args[])
	{
		System.out.println ("Hello World");
	}
}

// that's all folks ...

public strictfp class Main
{

	public static void proc (String args[])
	{
		System.out.println (args);
	}

	public static void main (String args[])
	{
		System.out.println ("Hello World");
	}
}

// that's all folks ...

