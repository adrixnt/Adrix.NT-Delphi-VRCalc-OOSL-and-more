// Java

public class Untitled
{
	// the recursive factorial function

	public static long Fact (int n)
	{
		if (n <= 0)
			return 1L;
		else
			return n * Fact (n - 1);
	}

	public static void main (String args[])
	{
		for (byte i = 0; i <= 10; ++i)
			System.out.println ("" + i + " : " + Fact(i));
	}
}
