/*/  C / C++  /*/

/*/   WARNING: REPLACE each occurrence of "__YourUnitName_*"
					with your Unique compilation unit name
/*/
/*/ WARNING: #define __exclude_unit_impl before #including this file /*/

#ifndef __YourUnitName_Unit__

/*/ [ unit ] /*/

	/*/ unit files contents (intf/impl) must be compiled only once at a time /*/
	#define __YourUnitName_Unit__
	/*/ by default, let's assume we are told to compile also this implementation section /*/
	#define __YourUnitName_Impl__
	/*/ check for a root-compile of this unit /*/
	#ifdef __exclude_unit_impl
		/*/ only the interface section of this unit is required because included by other units !!
		exclude the implementation part so it won't be compiled twice /*/
		#undef __YourUnitName_Impl__
	#else
		/*/ the implementation section of this unit must be compiled !!
		only interface sections of required units will be included
		exclude the implementation sections of any other required unit /*/
		#define __exclude_unit_impl
	#endif

/*/ [ interface section ] /*/

	/*/ put any #include file used by your interface section here /*/


	/*/ Any of Your C/C++ declared (types, procs, data) goes here /*/



	/*/ ... end of your unit interface code /*/

/*/_________________________________________________________________________________________________________________/*/

#ifdef __YourUnitName_Impl__

/*/ [ implementation section ] /*/

	/*/ your implementation's private use #include files goes here /*/


	/*/ >> write your unit's implementation code here ... /*/



	/*/ ... end of your unit implementation code /*/


#undef __YourUnitName_Impl__  /*/ forget this unit implementation once compiled! /*/
#endif /*/ implementation section /*/

#endif /*/ unit /*/

/*/  that's all folks ...  /*/